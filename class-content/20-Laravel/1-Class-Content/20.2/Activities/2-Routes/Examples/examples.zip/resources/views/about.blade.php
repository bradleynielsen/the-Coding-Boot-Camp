@extends('layout')

@section('title')
About Me
@stop

@section('content')
  <h1>A Little About Me</h1>
@stop
